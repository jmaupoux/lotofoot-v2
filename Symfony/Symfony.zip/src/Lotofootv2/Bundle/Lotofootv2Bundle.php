<?php

namespace Lotofootv2\Bundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class Lotofootv2Bundle extends Bundle
{
}
